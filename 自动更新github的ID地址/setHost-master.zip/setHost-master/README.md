# setHost
一键获取git的最新ip,并更新host文件
执行index.cmd文件即可
